package com.example.exercicio7;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import java.util.List;

public class pesquisa extends AppCompatActivity {

    private EditText rgm;
    private TextView mensagem;

    private Button botaoVoltar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pesquisa);

        botaoVoltar=findViewById(R.id.button2);
        rgm= findViewById(R.id.rgmAluno);
        mensagem = findViewById(R.id.resultadoBusca);

        botaoVoltar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(pesquisa.this, MainActivity.class);
                startActivity(intent);
            }
        });


    }
    public void pesquisar(View view){
        String rgmAluno = rgm.getText().toString();
        List<aluno> alunos = listaAlunos.getInstance().getListaAlunos();

        if(alunos.isEmpty()){
            mensagem.setText("Não há alunos cadastrados");
        }else {
            for (aluno cadaAluno:alunos) {
                if (cadaAluno.getRgm().equals(rgmAluno)){
                    Intent intent = new Intent(this, telaBusca.class);
                    intent.putExtra("Rgm",rgmAluno);
                    startActivity(intent);
                }else {
                    mensagem.setText("Não temos este aluno cadastrado");
                }
        }

    }



}
















}