package com.example.exercicio7;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import java.util.List;

public class Telacadastro extends AppCompatActivity {

    private EditText alunoRgm, alunoNome, notaParcial, trabalho, notaPri;
    private TextView txt;
    private Button botaoVoltar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_telacadastro);

        alunoNome = findViewById(R.id.nomeAluno);
        alunoRgm = findViewById(R.id.alunoRgm);
        notaParcial = findViewById(R.id.notaParcial);
        notaPri = findViewById(R.id.notaPri);
        trabalho = findViewById(R.id.notaParci);
        botaoVoltar = findViewById(R.id.button5);

        botaoVoltar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Telacadastro.this, MainActivity.class);
                startActivity(intent);
            }
        });

    }

    public void adicionarAluno(View view) {
        String rgm = alunoRgm.getText().toString();
        String nome = alunoNome.getText().toString();
        String notaParc = notaParcial.getText().toString();
        String notaPr = notaPri.getText().toString();
        String trab = trabalho.getText().toString();

        // faz a verificação do rgm para ver se o aluno ja tem cadastro
        if (existeAlunoComRGM(rgm)) {
            txt.setText("Aluno com o mesmo RGM já está cadastrado.");
        } else {
            //chama o meteodo validar dados para verificar se falta alguma informação
            String mensagemErro = validarDados(rgm, nome, notaParc, notaPr, trab);

            if (mensagemErro.isEmpty()) {
                // Verifica através do método valida dados se os dados estão corretos, se sim, cria o novo aluno
                aluno novoAluno = new aluno(rgm, nome, Double.parseDouble(notaParc), Double.parseDouble(notaPr), Double.parseDouble(trab));

                // Adicionar aluno na lista
                listaAlunos.getInstance().adicionarAluno(novoAluno);

                // Leva para a tela de cadastro realizado
                Intent intent = new Intent(this, cadastroRealizado.class);
                startActivity(intent);

            } else {
                // Caso falte algum dado, ele cai aqui e mostra qual dado está faltando
                txt.setText("Verifique seus dados:\n" + mensagemErro);
            }
        }
    }


    public String validarDados(String rgm, String nome, String notaParcial, String notaPri, String trabalho) {
        String mensagemErro = "";

        if (rgm.isEmpty()) {
            mensagemErro += "Está faltando o RGM.\n";
        }

        if (nome.isEmpty()) {
            mensagemErro += "Está faltando o nome.\n";
        }

        if (notaParcial.isEmpty()) {
            mensagemErro += "Está faltando a nota parcial.\n";
        }

        if (notaPri.isEmpty()) {
            mensagemErro += "Está faltando a nota PRI.\n";
        }

        if (trabalho.isEmpty()) {
            mensagemErro += "Está faltando a nota de trabalho.\n";
        }

        return mensagemErro;
    }
    private boolean existeAlunoComRGM(String rgm) {
        // chama a lista de alunos
        List<aluno> alunos = listaAlunos.getInstance().getListaAlunos();

        // usa um for each para consultar a lista
        for (aluno aluno : alunos) {
            if (aluno.getRgm().equals(rgm)) {
                return true;
            }
        }

        return false;
    }
}