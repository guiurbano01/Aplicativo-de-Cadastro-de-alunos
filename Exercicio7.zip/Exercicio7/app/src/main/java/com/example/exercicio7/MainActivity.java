package com.example.exercicio7;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    private Button botaoCadastro,botaoPesquisa,botaoEditar,botaoApagar,buscarTodos,botaoSobre;
    private TextView mensagem;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);




        mensagem = findViewById(R.id.textView16);
        botaoCadastro = findViewById(R.id.cadastrar);
        botaoPesquisa = findViewById(R.id.pesquisa);
        botaoEditar = findViewById(R.id.button3);
        botaoApagar=findViewById(R.id.button4);
        buscarTodos = findViewById(R.id.button6);
        botaoSobre = findViewById(R.id.button7);



        botaoSobre.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this, nomesAlunosExercicio.class);
                startActivity(intent);
            }
        });


        buscarTodos.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this, listarTodos.class);
                startActivity(intent);
            }
        });



        botaoApagar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this, apagarAluno.class);
                startActivity(intent);
            }
        });


        botaoEditar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this, editarDados.class);
                startActivity(intent);
            }
        });


        botaoPesquisa.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this, pesquisa.class);
                startActivity(intent);
            }
        });

        botaoCadastro.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this, Telacadastro.class);
                startActivity(intent);
            }
        });

    }



}