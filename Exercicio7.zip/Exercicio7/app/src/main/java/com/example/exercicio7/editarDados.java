package com.example.exercicio7;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import java.util.List;

public class editarDados extends AppCompatActivity {

    private EditText alunoRgm, alunoNome, notaParcial, trabalho, notaPri;
    private TextView alunoEncontrado;
    private Button voltar;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_editar_dados);

        alunoEncontrado = findViewById(R.id.econtraAluno);
        alunoNome = findViewById(R.id.nome);
        alunoRgm = findViewById(R.id.rgm);
        notaParcial = findViewById(R.id.notaParci);
        notaPri = findViewById(R.id.notaPri);
        trabalho = findViewById(R.id.trabalhos);
        voltar = findViewById(R.id.button11);


        voltar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(editarDados.this, MainActivity.class);
                startActivity(intent);
            }
        });


    }
    public void buscarAluno(View view) {
        List<aluno> alunos = listaAlunos.getInstance().getListaAlunos();
        String rgm = alunoRgm.getText().toString();

        if(alunos.isEmpty()){
            alunoEncontrado.setText("Não exite alunos cadastrados");
        }else {
            for (aluno alunoBusca : alunos) {
                if (alunoBusca.getRgm().equals(rgm)) {
                    alunoNome.setText(alunoBusca.getNome());
                    alunoRgm.setText(alunoBusca.getRgm());
                    notaParcial.setText(String.valueOf(alunoBusca.getNotaParcial()));
                    notaPri.setText(String.valueOf(alunoBusca.getNotaPri()));
                    trabalho.setText(String.valueOf(alunoBusca.getTrabalho()));
                    alunoEncontrado.setText("");
                }else {
                    alunoEncontrado.setText("Aluno não encontrado");
                }
            }

        }
    }
    public void editarAluno(View view){
        List<aluno> alunos = listaAlunos.getInstance().getListaAlunos();
        String rgm = alunoRgm.getText().toString();
        String nome = alunoNome.getText().toString();
        double notaParc= Double.parseDouble(notaParcial.getText().toString());
        double notaPr= Double.parseDouble(notaPri.getText().toString());
        double trabalhos= Double.parseDouble(trabalho.getText().toString());
        String editado = "";
        for (aluno alunoBusca : alunos) {
            if (alunoBusca.getRgm().equals(rgm)) {
                alunoBusca.setRgm(rgm);
                alunoBusca.setNome(nome);
                alunoBusca.setNotaPri(notaPr);
                alunoBusca.setTrabalho(trabalhos);
                alunoBusca.setNotaParcial(notaParc);
                editado = "sim";
            }else {
                editado="nao";
            }
        }
        alunoNome.setText("");
        alunoRgm.setText("");
        notaParcial.setText("");
        notaPri.setText("");
        trabalho.setText("");

        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);

    }
}