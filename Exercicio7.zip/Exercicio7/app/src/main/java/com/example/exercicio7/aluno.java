package com.example.exercicio7;




public class aluno {
    private String rgm;
    private String nome;
    private double notaParcial;
    private double notaPri;
    private double trabalho;

    public aluno(String rgm, String nome, double notaParcial, double notaPri, double trabalho) {
        this.rgm = rgm;
        this.nome = nome;
        this.notaParcial = notaParcial;
        this.notaPri = notaPri;
        this.trabalho = trabalho;
    }

    public String getRgm() {
        return rgm;
    }

    public void setRgm(String rgm) {
        this.rgm = rgm;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public double getNotaParcial() {
        return notaParcial;
    }

    public void setNotaParcial(double notaParcial) {
        this.notaParcial = notaParcial;
    }

    public double getNotaPri() {
        return notaPri;
    }

    public void setNotaPri(double notaPri) {
        this.notaPri = notaPri;
    }

    public double getTrabalho() {
        return trabalho;
    }

    public void setTrabalho(double trabalho) {
        this.trabalho = trabalho;
    }
}