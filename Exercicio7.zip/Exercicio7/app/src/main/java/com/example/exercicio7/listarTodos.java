package com.example.exercicio7;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import java.util.List;

public class listarTodos extends AppCompatActivity {
private Button botao;
private TextView nomeAluno;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_listar_todos);

        List<aluno> alunos = listaAlunos.getInstance().getListaAlunos();
        nomeAluno = findViewById(R.id.textView17);


        botao = findViewById(R.id.voltar);

        botao.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(listarTodos.this, MainActivity.class);
                startActivity(intent);
            }
        });

        for (aluno aluno:alunos) {
            nomeAluno.append("Nome: "+aluno.getNome()+"\n"+"RGM: "+aluno.getRgm()+"\n"+"Nota Pri: "+aluno.getNotaPri()+"\n"+"Trabalho: "+aluno.getTrabalho()+"\n"+"Nota Parci: "+aluno.getNotaParcial()+"\n \n \n");
        }

    }
}