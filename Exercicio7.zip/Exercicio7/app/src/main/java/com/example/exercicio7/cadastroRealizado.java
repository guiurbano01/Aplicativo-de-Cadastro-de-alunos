package com.example.exercicio7;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import java.util.List;

public class cadastroRealizado extends AppCompatActivity {

    private TextView rgm,nome,notaPric,trabalhos,notaParc;
    private Button botao;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cadastro_realizado);

        listaAlunos listaAlunosInstance = listaAlunos.getInstance();

        // Obtém a lista de alunos
        List<aluno> alunos = listaAlunosInstance.getListaAlunos();

        nome = findViewById(R.id.nome);
        rgm = findViewById(R.id.rgmAluno);
        notaParc = findViewById(R.id.parcialNota);
        notaPric = findViewById(R.id.priNota);
        trabalhos = findViewById(R.id.trabalhosNota);

        if (!alunos.isEmpty()) {
            // Obtém o último aluno adicionado (último elemento na lista)
            aluno ultimoAluno = alunos.get(alunos.size() - 1);


            // Define os valores nos TextViews com os detalhes do último aluno
            nome.setText(ultimoAluno.getNome());
            rgm.setText( ultimoAluno.getRgm());
            notaParc.setText(String.valueOf(ultimoAluno.getNotaParcial()));
            notaPric.setText(String.valueOf(ultimoAluno.getNotaPri()));
            trabalhos.setText(String.valueOf(ultimoAluno.getTrabalho()));
        }


        botao = findViewById(R.id.voltar);
        botao.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(cadastroRealizado.this, MainActivity.class);
                startActivity(intent);
            }
        });
    }
}