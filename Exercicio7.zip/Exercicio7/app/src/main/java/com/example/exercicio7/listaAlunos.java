package com.example.exercicio7;

import java.util.ArrayList;
import java.util.List;

public class listaAlunos {
    private static listaAlunos instance;
    private List<aluno> listaAlunos;

    private listaAlunos() {
        listaAlunos = new ArrayList<>();
    }

    public static listaAlunos getInstance() {
        if (instance == null) {
            instance = new listaAlunos();
        }
        return instance;
    }

    public void adicionarAluno(aluno aluno) {
        listaAlunos.add(aluno);
    }

    public List<aluno> getListaAlunos() {
        return listaAlunos;
    }
    public void removerAluno(aluno aluno) {
        listaAlunos.remove(aluno);
    }



}
