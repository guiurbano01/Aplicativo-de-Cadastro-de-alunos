package com.example.exercicio7;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import java.util.List;

public class telaBusca extends AppCompatActivity {

    private Button botao;
    private TextView rgm,nome,notaPric,trabalhos,notaParc;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tela_busca);

        List<aluno> alunos = listaAlunos.getInstance().getListaAlunos();
        Intent intent = getIntent();
        String textoRecebido = intent.getStringExtra("Rgm");

        nome = findViewById(R.id.nome);
        rgm = findViewById(R.id.rgmAluno);
        notaParc = findViewById(R.id.parcialNota);
        notaPric = findViewById(R.id.priNota);
        trabalhos = findViewById(R.id.trabalhosNota);

        for (aluno alunoBusca:alunos) {
            if(alunoBusca.getRgm().equals(textoRecebido)){
                nome.setText(alunoBusca.getNome());
                rgm.setText( alunoBusca.getRgm());
                notaParc.setText(String.valueOf(alunoBusca.getNotaParcial()));
                notaPric.setText(String.valueOf(alunoBusca.getNotaPri()));
                trabalhos.setText(String.valueOf(alunoBusca.getTrabalho()));
            }
        }

        botao = findViewById(R.id.voltar);
        botao.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(telaBusca.this, MainActivity.class);
                startActivity(intent);
            }
        });
    }
}