package com.example.exercicio7;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import java.util.List;

public class apagarAluno extends AppCompatActivity {

    private EditText alunoRgm, alunoNome, notaParcial, trabalho, notaPri;
    private TextView alunoEncontrado;
    private Button voltar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_apagar_aluno);

        alunoEncontrado = findViewById(R.id.econtraAluno);
        alunoNome = findViewById(R.id.nome);
        alunoRgm = findViewById(R.id.rgm);
        notaParcial = findViewById(R.id.notaParci);
        notaPri = findViewById(R.id.notaPri);
        trabalho = findViewById(R.id.trabalhos);
        voltar=findViewById(R.id.button10);



        voltar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(apagarAluno.this, MainActivity.class);
                startActivity(intent);
            }
        });



    }

    public void buscarAluno(View view) {
        List<aluno> alunos = listaAlunos.getInstance().getListaAlunos();
        String rgm = alunoRgm.getText().toString();

        if(alunos.isEmpty()){
            alunoEncontrado.setText("Não existe alunos cadastrados");
        }else {
            for (aluno alunoBusca : alunos) {
                if (alunoBusca.getRgm().equals(rgm)) {
                    alunoNome.setText(alunoBusca.getNome());
                    alunoRgm.setText(alunoBusca.getRgm());
                    notaParcial.setText(String.valueOf(alunoBusca.getNotaParcial()));
                    notaPri.setText(String.valueOf(alunoBusca.getNotaPri()));
                    trabalho.setText(String.valueOf(alunoBusca.getTrabalho()));
                    alunoEncontrado.setText("");
                }else {
                    alunoEncontrado.setText("Aluno não encontrado");
                }
            }

        }
    }

    public void apagarAluno (View view){
        String rgm = alunoRgm.getText().toString();
        List<aluno> alunos = listaAlunos.getInstance().getListaAlunos();
        for (aluno aluno: alunos) {
            if(aluno.getRgm().equals(rgm)){
                listaAlunos.getInstance().removerAluno(aluno);
                alunoEncontrado.setText("Aluno apagado");
                alunoNome.setText("");
                alunoRgm.setText("");
                notaParcial.setText("");
                notaPri.setText("");
                trabalho.setText("");
            }
        }

    }
}


