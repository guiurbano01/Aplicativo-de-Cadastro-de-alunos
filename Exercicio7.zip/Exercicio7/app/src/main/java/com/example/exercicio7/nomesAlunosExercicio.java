package com.example.exercicio7;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class nomesAlunosExercicio extends AppCompatActivity {

    private Button botaoVoltar;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_nomes_alunos_exercicio);

        botaoVoltar = findViewById(R.id.button12);

       botaoVoltar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(nomesAlunosExercicio.this, MainActivity.class);
                startActivity(intent);
            }
        });
    }
}